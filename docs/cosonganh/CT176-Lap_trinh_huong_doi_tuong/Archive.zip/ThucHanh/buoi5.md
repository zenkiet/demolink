# ![Executive Malepng](https://raw.githubusercontent.com/Zenfection/Image/master/2021/03/05-19-06-19-Executive%20Male.png) Buổi thực hành 5 - Lập trình OOP![Executive Femalepng](https://raw.githubusercontent.com/Zenfection/Image/master/2021/03/05-19-07-40-Executive%20Female.png)

> ![icons8-questions.png](https://raw.githubusercontent.com/Zenfection/Image/master/2021/03/05-12-38-09-icons8-questions.png) Sử dụng phương pháp lập trình  `Java OOP` để viết khai báo các lớp và định nghĩa các phương thức cần thiết cho mô hình bài toán quản lý hoá đơn bán hàng đơn giản như sau : 
> 
> ![Ảnh chụp Màn hình 2021-03-12 lúc 11.57.40.png](https://raw.githubusercontent.com/Zenfection/Image/master/2021/03/12-11-57-42-A%CC%89nh%20chu%CC%A3p%20Ma%CC%80n%20hi%CC%80nh%202021-03-12%20lu%CC%81c%2011.57.40.png)
> 
> Sau đó, sinh viên viết một lớp có chứa hàm `main()` để thực thi một chương trình quản lý hoá đơn hàng hàng trên.

Giải